# 固定 overlap 首轮学习诊断

记录日期：2026-10-14。对象为 `checkpoints/overlap_proxy_mappo_1701_20261014` 首轮 CGS 示范、BC 与 MAPPO 训练。本记录不改变正在执行的训练，不读取独立测试成绩，也不以训练集拟合率替代策略评估。

## 当前结论与证据边界

第 5 个示范场景存在很长的无地面接触区间。CGS 的 2 小时接触计划内没有交付路径，因此每秒重复输出 WAIT。示范采集保留了这些连续决策，使单个场景占据大量 agent observation rows。这是已确认的数据分布现象，但不是训练已经失败的结论。

特别需要区分：

- “2 小时计划内无路径”不等于“整个 6 小时仿真没有交付机会”。本场景全星座首次地面接触约在 4.72 小时，仿真后段仍有机会。
- 34,816 个 observation rows 不是 34,816 个独立任务、独立图像或独立环境。它们主要来自同一批待处理分片随时间重复出现。
- 本段数值来自前 5 个示范 episode 的控制台记录；完整 8 段统计见后文，现已与落盘 `warmstart.json` 核对。
- 首任务与几何证据是独立重建确认的。此次仅重建到首任务出现的第 81 步，没有另跑一次完整训练或完整教师 rollout。

## 可复算场景

输入配置为 `examples/overlap_proxy/config.json`、`examples/overlap_proxy/distribution.json`，通过 `ScenarioDistribution(...).training_case(1701, 5)` 生成。

| 参数 | 实际值 |
|---|---|
| case / 环境随机种子 | `train_1701_5` / `1706` |
| 配置 SHA256 | `69da747d5e3042e6d33cacb29c360554e179ea7628728f461c97e03c2c27dba4` |
| 审计时运行源码 SHA256 | `9c941294963730c6622444101441fe9c8b60977783e6bf30f65b3317f83fbf03` |
| 星座 | 2 轨道面，每面 6 星，共 12 星 |
| 高度 / 倾角 | 743.1751519461147 km / 97.95803081792415 deg |
| RAAN / 相位偏移 | 349.6074640383716 deg / 302.808741565302 deg |
| 角色 / 成像源 | `uniform` / `[0, 3, 6, 9]` |
| 图像工作负载 | `p0019`，6573 x 3727 像素，40 窗口，12 个调度包 |
| 时间偏移 | 13503.795351965367 s |
| 起始 UTC | `2026-03-20T21:15:03.795352+00:00` |
| 实际总到达率 | 0.0040620945147197916 image/s |
| 全程 / 到达期 / 步长 | 21600 s / 7200 s / 1 s |
| 预测范围 / 地面预测采样 / 可见性刷新 | 7200 s / 30 s / 10 s |
| 地面站 / 最小仰角 | 北京、乌鲁木齐 / 15 deg |
| 计算 | 所有卫星 1 U/s，`work_conserving`，地面 3.2396827056638866 U/s |
| 结果中继 | 开启，最多 8 跳 |

下面的代码只初始化同一环境、读取已预计算几何，并执行到首个任务出现。预计算数据覆盖全程 6 小时及额外 2 小时预测范围；其 1 秒采样下的几何门限通过时间不等于最终传输完成时间。

```python
import json
import numpy as np
from sim.config import load_config
from sim.env import SimulationEnv
from sim.marl.scenarios import ScenarioDistribution
from sim.marl.decision import decision_state
from sim.scheduler.literature import CGSComputeAdapted, contact_plan

base = load_config("examples/overlap_proxy/config.json")
distribution = ScenarioDistribution("examples/overlap_proxy/distribution.json", base)
cfg, case = distribution.training_case(1701, 5)
env = SimulationEnv(cfg)
try:
    first_visible = {}
    for sid in range(cfg.num_sats):
        for gid, station in env.ground_stations.items():
            altitude = env.vis_cache._precomputed[sid, gid][0]
            indices = np.flatnonzero(altitude >= station.min_elevation_deg)
            first_visible[f"{sid}:{gid}"] = int(indices[0]) if len(indices) else None
    print(json.dumps(first_visible))
    while not env.tasks:
        env.step([])
    state = decision_state(env.export_state())
    teacher = CGSComputeAdapted()
    actions = teacher.select_actions(state)
    print(env.time, [action.action_type.value for action in actions], dict(teacher.stats))
    print("ground contacts", sum(isinstance(c.target, tuple)
                                 for c in contact_plan(state).contacts))
finally:
    env.close()
```

建议用 `.venv/bin/python`，并令 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`。该检查读取内部预计算缓存用于审计，不能作为正式策略可用的额外信息。

## 几何与首任务证据

每星第一次达到地面站最小仰角的时刻，单位为相对仿真起点的秒：

| 卫星 | 北京 | 乌鲁木齐 |
|---|---:|---:|
| 0，成像源 | 17913 | 23993 |
| 1 | 17000 | 23091 |
| 2 | 21774 | 27830 |
| 3，成像源 | 20788 | 26851 |
| 4 | 19815 | 25884 |
| 5 | 18856 | 24930 |
| 6，成像源 | 24921 | 未在 28800 s 范围内出现 |
| 7 | 23935 | 未在 28800 s 范围内出现 |
| 8 | 22958 | 未在 28800 s 范围内出现 |
| 9，成像源 | 21991 | 27955 |
| 10 | 21040 | 27038 |
| 11 | 20131 | 未在 28800 s 范围内出现 |

独立重建的首任务状态：`time=81`，任务数 1，源星 9，截取给策略的候选分片数 4；CGS 动作为 `[WAIT, WAIT, WAIT, WAIT]`，统计为 `requests=4`、`wait_no_feasible_delivery=4`，接触计划内地面边数量为 0，全部卫星的 `next_gs_windows` 均为 null。

因此，在约 `17000 - 7200 = 9800` 秒之前，预测范围尚不足以看到全星座第一次地面接触。实际计划首次提供可用边还受 30 秒采样、可见性缓存、路径接续和传输时间影响，9800 秒只是这个必要条件的理论边界。

还可得到一个与算法无关的场景限制：所有任务在前 7200 秒内到达，而首次任何地面接触为 17000 秒。完整结果必须落地的指标下，全部任务的 30、60、120 分钟交付率均只能为零，因为最晚到达任务的 120 分钟评价窗口也在 14400 秒附近结束。因此本场景 `J <= 0.25`；这个上界不是实测最终成绩。对于产生时间早于约 2600 秒的任务，即便立即计算并无排队，其 240 分钟窗口也早于首次地面接触。结果中继能利用其他星稍后的窗口，但不能制造不存在的地面接触。

## 示范采样为何被 WAIT 主导

运行中控制台前五段记录如下；卫星/地面卸载均汇总为相应类别，最终细分动作索引以日志为准。

| BC episode | Agent rows | WAIT 标签 | LOCAL 标签 | 卫星卸载标签 | 地面卸载标签 |
|---|---:|---:|---:|---:|---:|
| 1 | 75 | 0 | 300 | 0 | 0 |
| 2 | 45 | 0 | 90 | 0 | 0 |
| 3 | 47 | 0 | 92 | 2 | 0 |
| 4 | 228 | 0 | 874 | 36 | 2 |
| 5 | 34816 | 138952 | 312 | 0 | 0 |

第 5 段占前五段 observation rows 的 `34816 / 35211 = 98.8782%`。前五段总标签数为 140660，其中 WAIT 占 `138952 / 140660 = 98.7857%`。一个 agent row 可以包含 1 至 4 个实际分片标签，因此 row 分母与 label 分母不能混用。单纯恒定预测 WAIT 已能在这段标签分布上获得约 98.79% 的表面 agreement，但可能完全不能执行本地计算。

代码链条为：

1. `sim/cache/visibility.py` 的 `_sampled_window` 只返回预测范围内第一段地面可见窗口，范围内无窗口时返回 None。
2. `sim/scheduler/literature.py` 的 `contact_plan` 跳过 None 地面窗口；`CGSComputeAdapted.select_actions` 在 `choose_opportunity` 无可交付机会时返回 WAIT，并累计 `wait_no_feasible_delivery`。
3. `sim/marl/imitation.py` 的 `collect_demonstrations` 对每个仿真步查询教师；只要 agent 有待调度分片，就把该 observation row 加入样本。这里没有对连续 WAIT、相同任务或相同 episode 去重。
4. `merge_demonstrations` 直接拼接各 episode；`fit_demonstrations` 随机打乱 agent rows，再对有效 tile labels 计算未加类别权重的交叉熵。训练不保证每个环境、每个任务或每类动作贡献相同权重。

上述机制解释了偏斜为何产生，但不能由此断言模型无法区分“当前无法交付”和“可以本地计算”的状态。该区别需要观察拟合后的分类召回、实际验证动作与完整交付成绩。

## 首轮 pooled BC 拟合结果

运行中 8 段示范采集与拟合已完成；控制台报告 `samples=54310`、`loss=0.02180`、`agreement=0.99876454`。`teacher_bc.pt` 已于本地时间 18:28:31 写入，`initial.pt` 写入于 18:05:45，二者相差 22 分 46 秒。这个时间包含示范采集与 30 个 BC epoch，不是单独的训练计算耗时或决策耗时；后续固定验证尚未包含在内。

| 有效分片标签类别 | 数量 | 拟合后类别召回率 | 与报告值一致的误判数 |
|---|---:|---:|---:|
| WAIT，动作 0 | 214640 | 1.0 | 0 |
| LOCAL，动作 1 | 2244 | 0.89839572 | 228 |
| 邻星卸载，动作 2 | 38 | 0.0 | 38 |
| 地面卸载，动作 10 | 2 | 0.0 | 2 |
| 总计 | 216924 | 总体 agreement 0.99876454 | 268 |

该轮 WAIT 占标签的约 98.95%。`1 - 268 / 216924 = 0.99876454`，因此总体高 agreement 与 LOCAL 约 10.16% 的漏判、40 个卸载标签全漏并不矛盾。类别支持度尤其重要：地面卸载只有 2 个标签，无法据此建立稳健的泛化结论。上述统计已与落盘 `warmstart.json` 复核；拟合统计本身不是对 BC 验证效果的判断。

已确认的偏斜值得作为独立 BC 对照处理。建议保持相同初始 checkpoint、相同 8 个训练 case 和相同优化步预算，采用每个 episode 的有效 tile 标签平均损失再对 episode 等权平均：

```text
L = (1 / E) sum_e [(1 / N_e) sum_(i in valid tile labels of episode e) CE_i]
```

这里 `N_e` 是有效 tile 标签数而不是 agent rows。应缓存真实 observations、tile masks、action masks、teacher actions 及 episode 索引，并保留对应配置、任务轨迹和源码哈希。按当前 54,310 rows、254 个 float32 特征、4 个 tile mask、48 个 action mask 和 4 个 int64 标签计算，张量原始大小约 59.7 MB；存档还需少量 metadata。重放采集的初步预算约 20--30 分钟，来源是本机原始采集与拟合的实际总耗时；最终验证需额外计时。这只是独立对照建议，未修改当前训练，也不能用独立测试结果选择权重。

## 结果解释的核验项目

`warmstart.json` 与初始固定验证已经落盘，后续完整训练报告应保留以下解释：

- 最终 8 段各自的 row 数、有效标签数、WAIT 占比，以及 teacher rollout 的任务数和交付结果。
- `pooled_fits.class_recall` 中 WAIT、LOCAL、卫星卸载、地面卸载各索引的召回；只有总体 agreement 高不能证明策略学会调度。
- BC 在固定验证面板上的 J、四个年龄点、受限时延，以及与 local/CGS 的逐 case 差异。教师 rollout 的结果不是学生 BC 的结果。
- PPO 各次更新的 active rows、KL、动作分布与固定验证表现；不同随机训练场景的 J 不构成配对改善曲线。
- 若 `best.pt` 对应 episode 0，选择结果仍然是 BC/warmstart，不能记为强化学习收益。报表仅由日志推断选择轮次；需要二进制检查时应另行核实。

`analysis/report_overlap_study.py` 已输出这些采样占比及类别召回信息。当前这轮原始协议应完整保留；若之后采用限制连续 WAIT 样本、按场景/任务重加权或其他教师规则，应作为另一个独立实验，不回写原始结果。

## 独立等权 BC 对照的执行约定

独立脚本为 `analysis/train_episode_equal_bc.py`，输出目录为 `checkpoints/overlap_proxy_balanced_bc_1701_20261014`。它使用原 `initial.pt`、原 8 个训练场景及原 CGS 教师，4 个单线程 worker 采集真实轨迹。每段缓存包含 observations、tile masks、action masks、teacher labels、配置和完整环境汇总；索引保留 SHA256。只有 `demonstrations/` 缓存目录被定向忽略，训练记录与最终模型不被忽略。

设总 observation rows 为 R，小批次实际行数为 B，第 e 段有效标签数为 N_e。按全部 rows 均匀打乱的小批次使用：

```text
L_hat = R / (E * B) * sum_(valid labels in current batch) CE / N_episode
```

该估计在固定模型下对目标 L 无偏；同一 row 的 1--4 个有效标签逐个计入，最后一个短 batch 使用实际 B，不除以当前 batch 的权重和。梯度裁剪仍与原 BC 一样为 0.5；无偏性描述的是裁剪前的目标梯度估计，不意味着裁剪后的更新仍是无偏估计。所有 rows 每个 epoch 遍历一次，30 个 epoch、512 rows/batch 对 54,310 rows 恰为 3,210 次更新。脚本在拟合前强制检查这个预算。

学习率为 0.001，Adam eps 为 1e-5。shuffle generator 接收同种子模型构造后的 Torch RNG 状态；教师采集使用确定性前向，没有 Torch 随机采样。最终 checkpoint 明确标注 `training_stage=episode_equal_bc`、`episode=0`、`validation=null`，保留外部 trainer SHA 及原配置/分布/source hash。该脚本不运行 validation 或 test；拟合后的分类召回不是泛化性能。

第一次采集启动在尚未产生 episode 缓存时停止，原因是新分析脚本在复用 worker 时重复设置 PyTorch interop 线程数。修复将线程设置移到进程池 initializer；单 worker 连续两任务的回归测试通过，之后重新执行完整采集。原始 BC+PPO 训练未停止。初次启动的设置记录保留在同名前缀 `_initial_attempt` 目录，不作为实验结果。

第二次启动暴露了分析层的内存格式边界：`env.summary()` 的 workload manifest 含 tuple，而 JSON 规范化后的 manifest 含 list，原比较误拒绝相同内容。修复统一比较格式，仍逐项核验 manifest 及 SHA；之后用真实 overlap 环境生成任务，完整验证采集、缓存落盘、缓存加载、拟合、checkpoint 保存和重新加载。该次未完成的设置记录保留为 `_manifest_attempt`，不作为实验结果；正式采集仅使用修复后的单次完整输出。当前采集先保存真实 tensors，再执行核验，失败时会即时输出错误，不把未核验数据纳入训练。

正式重放第 5 段已核验真实缓存：仅有 26 个独立 task、312 个分片，却生成 34,816 条 observation rows、138,952 个 WAIT 标签及 312 个 LOCAL 标签。26 个任务最终全部在仿真 t=17,002 s 交付；按任务年龄重算，F30、F60、F120 均为 0，F240=18/26=0.69230769，J=0.17307692，受限平均时延为 12,959.23077 s。该证据进一步排除了“整个 6 小时没有交付机会”的解释：重复等待发生在有限预测视野内，仿真后段仍有地面窗口。这是 CGS 教师在训练场景上的轨迹，不能充当学生 BC 的验证结果。对应 task trace SHA256 为 `08e06268cc08cb87362f391d56233a4be6d6978ba21d4f1fe6ac9dbf70408372`。

## 独立等权 BC 的已完成拟合结果

8 段正式缓存及 30 个 epoch 已完成，实际 54,310 rows、216,924 个有效标签、3,210 次优化器更新。拟合 epoch 累计耗时 123.02030 s；该时间不包含示范采集、最终全样本统计或验证。8 段张量缓存合计 60,020,392 bytes，被输出目录内的 `.gitignore` 定向忽略。两段 WAIT 密集场景（5、8）共有 53,849 rows，占全部 rows 的 99.15117%；其余六段总共 461 rows。

| 动作 | 标签数 | 原 pooled BC 训练召回 | 等权 BC 训练召回 |
|---|---:|---:|---:|
| WAIT | 214640 | 1.00000000 | 0.99890048 |
| LOCAL | 2244 | 0.89839572 | 0.89304813 |
| 邻星卸载，动作 2 | 38 | 0.00000000 | 0.63157895 |
| 地面卸载，动作 10 | 2 | 0.00000000 | 0.00000000 |

等权模型在邻星卸载标签上正确 24/38 个，原模型为 0/38；LOCAL 正确数从 2016/2244 略降为 2004/2244，WAIT 有 236 个误判，地面卸载仍为 0/2。总体 agreement 从原模型的 0.99876454 降至 0.99773192。因此这一结果支持“卸载标签的拟合改善”，不支持“所有动作均改善”，更不能据此宣布验证性能提高。等权目标的最终全样本损失为 0.03031686；它与原训练打印的跨更新 pooled loss 0.02180 使用不同目标和统计时点，不应直接比较大小。

按该等权目标，WAIT、LOCAL、邻星卸载、地面卸载的标签总权重分别为 0.24899096、0.74314113、0.00759378、0.00027412。以上由每段标签分布和统一的 1/8 场景权重自然得到，没有使用验证或测试成绩调类别权重。

模型路径为 `checkpoints/overlap_proxy_balanced_bc_1701_20261014/teacher_bc.pt`，SHA256 为 `cb9a60c7ab2765171160db345100230b5f7c4dbacc4c580b412311f86ac99c35`；缓存索引 SHA256 为 `32363cdf1a26d9f5dae8dffc2fd4ef769c8c992570609577db57195c91e2a599`。完整拟合统计与每段元数据保存在同目录 `summary.json`，逐 epoch 记录在 `fit_log.jsonl`，已归档的外部训练脚本为 `trainer_source.py`。实际 `MARLPolicy` 加载入口已验证，观测协议为 3，stage 为 `episode_equal_bc`，episode 为 0，validation 为 null。

原始 `warmstart.json` 于本地时间 19:32 落盘后，已调用 `compare_original` 核验八段缓存的 samples、action_counts 与完整 metrics，逐项相同。独立核对记录为 `checkpoints/overlap_proxy_balanced_bc_1701_20261014/original_teacher_comparison.json`，包含原始 warmstart 与缓存索引 SHA。checkpoint 内的 pending 标记保留为拟合当时的事实，没有改写已冻结模型或元数据。

统一评估已完成等权模型的 12 个验证案例，J=0.78891528、四小时受限平均时延 3206.13568 s、最终完成 1012/1015；原始 BC 验证为 J=0.79328437、受限平均时延 3002.02892 s、最终完成 1015/1015。两者均低于 local 的 J=0.91591658，说明这次权重调整没有建立交付优势。测试评估也已生成，但不用于修改该对照或选择训练权重；完整方法比较由统一主表报告。

已有训练验证可通过 `analysis/export_overlap_validation.py` 导出，避免再执行相同轨迹。导出要求原始训练完整结束，核对 BC 的 `teacher_bc.pt` 与 `warmstart.pt` 逐 tensor 相同、PPO `last.pt` 对应末轮 validation 日志，并重算年龄指标、workload/TLE/task-trace 哈希。导出明确标记旧训练验证来源，未测的 `elapsed_s`、`decision_timing` 均为 null。独立等权 BC 的 checkpoint 则需另行评估，不能套用原始 BC 的验证轨迹。

导出器额外支持唯一明确的续训协议：`resume_parallel_validation.json`必须为schema_version 1、kind=`exact_cpu_resume_parallel_validation`且状态completed。它核验续训前后run/checkpoint/log的SHA、完整原日志字节前缀、原checkpoint的模型/优化器/RNG状态字段、配置与分布文件、归档及当前wrapper字节，以及全部并行validation调用的JSON规范化摘要和case顺序。原与新training_args只允许`resume=false`变为`resume=true`，其余完整metadata保持相同；BC对照原metadata，末轮PPO对照新metadata。导出清单保留完整续训证据，未知resume仍拒绝。正反例回归完成后，本轮实际八回合续训及末轮验证也已完成，sidecar状态为completed，并通过严格导出；这是单种子开发训练完成，不代表正式多种子实验完成。

## 完整训练与验证结论

归档为[验证导出](../../results/overlap_proxy_validation_learned_export_20261014/summary.json)。原BC的12案例等权J为0.7932843684236596、四小时限制平均时延3002.0289210517553 s；八回合末轮PPO分别为0.7745685411169482及3249.168543858977 s，二者最终均完成1015/1015个任务。PPO的J下降1.87158273个百分点，限制均值增加247.139623 s，最佳检查点仍为第0轮BC。这一轮不支持强化学习带来收益；最终完成数相同也不消除交付年龄的退化。完整测试也已完成，见[严格主表](../../results/overlap_proxy_study_20261014/summary.json)：原BC、末轮PPO和等权BC的测试J分别为82.5908%、81.2887%和78.8165%，本地为90.1886%；前两者最终完成1009/1009，等权BC为946/1009。测试未用于改写训练权重或选模。

原BC与等权BC的行为不同，详见[只读验证审计](../../results/overlap_learning_audit_20261014/summary.md)及[解释边界](../../results/overlap_learning_audit_20261014/interpretation.md)。原BC实际零卸载、最终全部源星本地计算，记录954761个WAIT提议、10470个LOCAL提议及8.961568 MB地面结果发送；等权BC在八个非强地面案例的619个任务上与local完成时刻完全一致，却在四个强地面案例集中退化，地面执行179.8图像工作当量、全验证下行22631.670 MB。后者没有动作计数日志，不能补造WAIT次数；图像当量不是完整任务数，相关现象也不是已完成干预的因果结论。

CGS教师与local的1015个任务中1014个完成时刻相同，一个提前537 s而未改变年龄评分，J同为0.9159165751592774。当前面板主要需要解释学生为何未保持简单有效的本地计算，而不是预设最优协同分配过于复杂。审计原始输入和数值结果保持冻结；解释文件已补充后续完成状态，原审计不因此变成PPO事件级审计。本节以完整验证和测试主表补充最终状态，仍不把单种子八回合开发诊断称为正式重复实验。
