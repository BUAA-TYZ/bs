# 卫星分布式任务调度仿真 — 实验报告

> 历史记录：以下数值来自模型 v2.0 之前的实现，存在轨道时间尺度、并发带宽和指标单位问题。
> 不能作为当前版本的性能结论，也不能与新结果直接比较。
> 当前研究与验证协议见 [research_plan.md](research_plan.md)，运行方式以仓库 README 顶部为准。

## 背景与研究问题

本仿真对比两种卫星遥感图像处理模式：

- **distributed**：卫星将大图切分为若干 tile，通过星间链路（ISL）分发给多颗卫星并行计算，每个 tile 计算完成后单独下传结果到地面站，全部 tile 完成则任务完成。
- **ground_compute**：卫星将完整图像上传至地面站，由地面站统一计算，计算完成则任务完成（无需再回传）。

**核心假设**：当卫星与地面站的单次通信窗口不足以传完完整大图时，分片调度（distributed）可利用多次短窗口分批完成传输，具有天然优势。

---

## 实验演进过程

### 阶段一：发现问题——初始参数下两种模式差距不大

**初始配置问题分析：**

| 问题 | 说明 |
|------|------|
| TLE 数据偏差 | 使用 `starlink_china_24.tle`，24 颗卫星均筛选自中国上空，与北京/乌鲁木齐地面站通信窗口过长 |
| 带宽过大 | 地面站带宽 100~120 Mbps，1024 MB 图像仅需 **68s** 即可传完，远短于典型过境窗口（中位 375s） |
| 分片无优势 | 单 tile（32 MB）仅需 2.1s 传输，任何一次过境都绰绰有余，分片失去实际意义 |

**判断标准：** 分片有意义的前提是 `图像大小 × 8 / 带宽 >> 典型过境窗口长度`。

---

### 阶段二：修复 TLE 数据——引入全球分散星座

**新 TLE 文件：** `data/tle/global_spread_inc53_24.tle`

- 24 颗 Starlink 卫星，轨道倾角均为 **53°**
- RAAN（升交点赤经）每 **15° 均匀分布**，覆盖 0°~360° 全球轨道面
- 不再集中在中国经度附近，每颗卫星约每 **97 分钟**过境中国一次，单次窗口约 **5~8 分钟**

**仿真起始时间：** `2026-03-20T17:30:00Z`（经扫描 24 小时确认为当日对北京可见性最低的时间窗口）

**过境窗口统计（5 小时仿真，20 颗活跃卫星，10° 仰角）：**

| 统计量 | 数值 |
|--------|------|
| 总过境次数 | 48 次 |
| 最短窗口 | 25 s |
| 中位窗口 | 375 s（约 6 分钟）|
| 最长窗口 | 805 s（约 13 分钟）|
| 平均窗口 | 414 s |

---

### 实验一：全球分散 TLE + 原始带宽参数

**配置：**

| 参数 | 值 |
|------|----|
| 图像大小 | 1024 MB |
| 地面站带宽 | 北京 120 Mbps / 乌鲁木齐 100 Mbps |
| 完整图传输时间 | 68s（北京）/ 82s（乌鲁木齐）|
| 单 tile 传输时间 | ~2s |
| 仿真时长 | 5 小时（3600 步 × 5s）|
| 卫星数量 | 20 |
| 调度策略 | Greedy Earliest Finish |

**结果：**

| 指标 | distributed | ground_compute | 说明 |
|------|-------------|----------------|------|
| 任务完成率 | 19.7%（57/290）| **23.1%（67/290）** | ground 反而更高 |
| tile 完成率 | **31.4%**（2912/9280）| 23.1% | distributed 更高 |
| 任务平均延迟 | **75 min** | 94 min | distributed 快 21% |
| 任务 P95 延迟 | 261 min | **237 min** | ground P95 反而更好 |
| tile 平均延迟 | **58 min** | 94 min | distributed 快 38% |
| 失败原因 | 无 | 无 | — |

**分析：**

虽然延迟上 distributed 已有优势，但 ground_compute 完成任务数反而更多。原因在于：

1. **带宽仍然偏大**：68s 传完 1024 MB，窗口（中位 375s）还是能完整传输，分片优势不显著
2. **完成条件不对称**：distributed 要求 32 个 tile 全部下传 result 才算任务完成，任何一个 tile 下传失败都会拖累整个任务；ground_compute 整任务上传后统一计算，无此问题
3. **结论**：带宽 120 Mbps 配合 1024 MB 图像，分片的核心优势（绕开窗口限制）**尚未真正体现**

---

### 实验二：全球分散 TLE + 大图 + 低带宽（推荐配置）

**配置调整依据：**

| 带宽 | 1024MB 传输时间 | 中位窗口(375s)能传几片 | 分片有意义？|
|------|-----------------|------------------------|------------|
| 120 Mbps（原始）| 68s | 整图都能传完 | 否 |
| 40 Mbps | 205s | 整图都能传完 | 否 |
| **20 Mbps** | **1638s（>4× 窗口）**| 约 7 片 | **是** |
| 10 Mbps | 3277s | 约 4 片 | 是，但过慢 |

> **20 Mbps** 对应现实中 S/X 波段小型卫星的有效吞吐量（考虑编码、链路余量、低仰角衰减后的实际速率）。

**最终配置：**

| 参数 | 值 |
|------|----|
| 图像大小 | **4096 MB**（高分辨率多光谱遥感图，4 波段×16384²×16bit） |
| 地面站带宽 | **北京 20 Mbps / 乌鲁木齐 20 Mbps** |
| 完整图传输时间 | **1638s（约 27 分钟）** |
| 单 tile（128 MB）传输时间 | **51s** |
| 一次过境（中位 375s）可传 tile 数 | **约 7 个**（共 32 个）|
| 传完完整图需要过境次数 | **约 4~5 次** |
| 仿真时长 | 5 小时（3600 步 × 5s）|
| 其余参数 | 同实验一 |

**结果：**

| 指标 | distributed | ground_compute | 差距 |
|------|-------------|----------------|------|
| 任务完成率 | **17.9%（52/290）** | 8.6%（25/290）| distributed **高 2.1 倍** |
| tile 完成率 | **29.0%（2688/9280）** | 8.6%（800/9280）| distributed **高 3.4 倍** |
| 任务平均延迟 | **65 min** | 160 min | distributed **快 59%** |
| 任务 P95 延迟 | **261 min** | 291 min | distributed 快 10% |
| tile 平均延迟 | **58 min** | 160 min | distributed **快 63%** |
| mem_full 失败 | 186 次 | **1216 次** | ground 失败 **6.5 倍** |

**分析：**

分片调度的优势在此配置下清晰体现：

1. **窗口利用效率**：ground_compute 需要等待约 4~5 次过境（累计 ~27 分钟有效传输时间）才能完成一张图上传，单次过境不够用时只能等下一个轨道周期（~97 分钟后）。distributed 每次过境传约 7 个 tile，不同卫星的不同过境机会可以并行利用，效率大幅提升。

2. **内存压力**：4096 MB 完整图需在源卫星上缓存至上传完毕（约 27 分钟），多任务积压时内存迅速耗尽（1216 次 mem_full）。分片后每个 tile 128 MB，计算完即释放内存，压力降低 32 倍。

3. **并行性**：distributed 将 32 个 tile 分发到多颗卫星并行计算，充分利用星间链路和多星算力；ground_compute 是串行瓶颈（单地面站顺序处理）。

---

### 实验三：66 颗卫星 × 3 种调度策略对比

**配置变更：**

| 参数 | 旧值 | 新值 |
|------|------|------|
| 卫星数量 | 24 | **66** |
| TLE 文件 | `global_spread_inc53_24.tle` | `global_spread_inc53_66.tle` |
| 其余参数 | — | 与实验二相同（4096 MB，20 Mbps） |

TLE 从 Starlink 完整星历（~9888 颗）中筛选 `52° < inc < 54°` 的候选卫星，按 RAAN 每 **5.45°** 均匀选取一颗，覆盖 0°~360° 全球轨道面。

**6 组实验结果：**

| 调度策略 | 模式 | 任务完成率 | tile 完成率 | 任务均延迟 | 任务 P95 延迟 | mem_full |
|----------|------|-----------|------------|-----------|--------------|---------|
| **greedy** | distributed | **14.1%（41/290）** | **31.0%** | **11.1 min** | 48.9 min | 0 |
| greedy | ground_compute | 8.6%（25/290）| 8.6% | 25.7 min | 55.4 min | 0 |
| load_aware | distributed | 4.1%（12/290）| 21.5% | 29.2 min | 49.7 min | 0 |
| load_aware | ground_compute | 8.6%（25/290）| 8.6% | 25.7 min | 55.4 min | 0 |
| random | distributed | 0.3%（1/290）| 23.5% | 6.8 min | 6.8 min | 0 |
| random | ground_compute | 8.6%（25/290）| 8.6% | 25.7 min | 55.4 min | 0 |

**关键观察：**

**1. ground_compute 三组数字完全一致**

`ground_compute` 模式下，调度策略对结果**没有任何影响**（均为 25/290 任务，25.7 min 均延迟）。原因在于：该模式的瓶颈完全在地面站的上行带宽（20 Mbps），卫星端的调度决策只决定"谁先上传"，但总带宽是固定的，排队顺序不影响整体吞吐。这验证了 `ground_compute` 是一个**带宽受限的稳定 baseline**。

**2. distributed 模式下策略差距显著**

- `greedy`（最早完成优先）表现最好：任务完成率 14.1%，比 `ground_compute` 高 **1.6 倍**，均延迟快 **57%**
- `load_aware`（资源感知）表现次之：tile 完成率（21.5%）尚可，但任务完成率（4.1%）远低于 ground_compute
- `random` 几乎无法完成任务（0.3%）：tile 随机分发导致 32 个 tile 无法集中完成，任务整体延迟极高

**3. load_aware tile 完成率 vs 任务完成率的背离**

`load_aware` 的 tile 完成率（21.5%）低于 `greedy`（31.0%，实为更高），但任务完成率（4.1%）远低于 `greedy`（14.1%）。说明 `load_aware` 倾向于把 tile 分散到不同卫星（均衡负载），导致同一个任务的 32 个 tile 完成时间分散，整体任务延迟变长。**任务完成要求所有 tile 同时完成，负载均衡策略与此目标不匹配。**

**4. 与 24 颗卫星（实验二）的对比**

| 指标 | 24 颗（greedy + distributed）| 66 颗（greedy + distributed）|
|------|------------------------------|------------------------------|
| 任务完成率 | 17.9% | 14.1% |
| tile 完成率 | 29.0% | 31.0% |
| 任务均延迟 | 65 min | **11.1 min** |
| mem_full | 186 | **0** |

66 颗卫星下任务完成率略有下降，但**均延迟从 65 分钟大幅降至 11 分钟**，mem_full 归零。原因：星座密度增大后过境窗口更频繁，tile 能更快找到下传机会；但同时更多卫星意味着任务到达时分散到更多卫星，每颗卫星的任务负载减少，反而使部分任务因无法凑齐全部 tile 而超时未计入完成（但延迟已大幅改善）。

---

## 关键参数影响总结

### 使分片有实际意义的条件

```
image_size_mb × 8 / bandwidth_mbps > 典型过境窗口长度
```

本仿真中典型过境窗口约 **375s**（中位数），因此：

- **带宽阈值**：`bandwidth_mbps < image_size_mb × 8 / 375`
  - 1024 MB 图像：需带宽 < **21.8 Mbps**
  - 4096 MB 图像：需带宽 < **87.4 Mbps**

### 真实带宽参考

| 频段/场景 | 典型有效吞吐 | 是否适合仿真 |
|-----------|-------------|-------------|
| UHF/VHF 早期小卫星 | 9.6 ~ 38 kbps | — |
| S 波段（微小卫星主流）| **1 ~ 10 Mbps** | 适合，分片优势显著 |
| X 波段小型化 | **20 ~ 80 Mbps** | 配合大图适合 |
| X 波段遥感卫星 | 150 ~ 300 Mbps（标称）| 需 >10 GB 图像才有意义 |

> 本仿真采用 **20 Mbps + 4096 MB** 对应 X 波段小卫星的保守有效吞吐，物理意义合理。

---

## 实验配置文件

最终推荐配置：`examples/config.yaml`

关键参数：

```yaml
num_sats: 66           # 66 颗（实验三）；24 颗见实验二
image_size_mb: 4096
num_tiles: 32
# 每个 tile 约 128 MB

ground_stations:
  - id: "gs_beijing"
    bandwidth_mbps: 20    # S/X 波段小卫星有效吞吐
  - id: "gs_urumqi"
    bandwidth_mbps: 20

topology:
  tle_file: "data/tle/global_spread_inc53_66.tle"   # 66 颗，RAAN 每 5.45° 一颗
  start_time_utc: "2026-03-20T17:30:00Z"

sim_steps: 3600   # 5 小时，覆盖约 3 个轨道周期
```

---

## 结论

| 结论 | 说明 |
|------|------|
| 分片调度的核心优势是**绕开单次窗口限制** | 只有当完整图传输时间远超单次过境窗口时，优势才能体现 |
| TLE 数据选取影响显著 | 集中在地面站上方的 TLE 会虚高通信机会，掩盖分片优势 |
| 带宽参数需与图像大小匹配 | 推荐用 `image_size_mb × 8 / bandwidth_mbps > 窗口中位数` 作为校验条件 |
| distributed 的内存效率更高 | tile 粒度小，计算完即释放，大幅减少 mem_full 失败 |
| ground_compute 是强力 baseline | 在带宽充足时甚至优于分布式，是衡量分片真实收益的合理基准 |

---

## Phase 2 — 窗口感知贪心策略（WindowAwareGreedy）

### 设计动机

`GreedyEarliestFinish` 在估算下传等待时间时，对不可见地面站的卫星使用固定 60s 惩罚。
实际上，卫星的下次过境时间可能在 5~90 分钟之间，固定惩罚会导致错误的调度决策：
- 对短期内会过境的卫星高估延迟（倾向于不必要地卸载）
- 对长期不可见的卫星低估延迟（错误地倾向于本地计算）

### 核心改进

利用 `export_state()` 中 `satellites[sat_id]["next_gs_windows"]` 字段（`{gs_id: (starts_in_s, duration_s)}`）：

| 情况 | 旧方案 (GreedyEarliestFinish) | 新方案 (WindowAwareGreedy) |
|------|-------------------------------|---------------------------|
| 当前可见地面站 | 0 s | 0 s（不变）|
| 有预测过境窗口 | 60 s（固定惩罚）| `starts_in_s`（真实等待）|
| 预测窗口内均无 | 60 s | 5400 s（1.5h 保守值）|

### 文件位置

`sim/scheduler/window_aware.py`

---

## Phase 3 — MARL 调度策略（IPPO + Parameter Sharing）

### 架构设计

**观测空间（89 维，num_gs=2 时）：**

| 区块 | 维度 | 说明 |
|------|------|------|
| 自身状态 | 5 | 时间、队列、内存、显存、计算进度 |
| 地面站窗口（×2 GS） | 8 | 可见性、窗口开始/持续时间、带宽 |
| 邻居信息（×8 slots） | 48 | ISL 带宽、队列、内存、可见性、最近窗口 |
| 待调度 tile（×4 slots） | 28 | 大小、计算量、显存需求、等待时间、任务聚合度 |

**动作空间（12 维，离散，per tile slot）：**

| 动作 | 含义 |
|------|------|
| 0 | WAIT（不动）|
| 1 | LOCAL（本地计算）|
| 2~9 | OFFLOAD 到邻居 slot 0~7（按 ISL 带宽降序）|
| 10~11 | OFFLOAD 到地面站 gs_0 / gs_1 |

**网络结构（SatActorCritic，~102K 参数）：**

```
Input (89-dim) →
  Linear(89, 256) + LayerNorm + GELU →
  Linear(256, 256) + LayerNorm + GELU →
┌─────────────────────────────────────┐
│ Policy head: Linear(256, 4×12)      │ → softmax per tile → action
│ Value  head: Linear(256, 1)         │ → scalar baseline
└─────────────────────────────────────┘
```

所有 66 颗卫星共享同一套权重（Parameter Sharing）。

**训练算法：IPPO（Independent PPO）+ GAE(λ)**

| 超参数 | 推荐值 |
|--------|--------|
| Rollout steps | 128 |
| PPO epochs | 4 |
| Minibatch size | 256 |
| Learning rate | 3e-4 |
| γ（discount） | 0.99 |
| λ（GAE） | 0.95 |
| clip_eps | 0.2 |
| vf_coef | 0.5 |
| ent_coef | 0.01 |

**Reward 设计：**

| 事件 | 奖励 |
|------|------|
| Tile 完成 | +1.0 |
| 任务完成（所有 tile DONE）| +10.0 |
| Tile 失败（mem_full/link_down 等）| -2.0 |
| 每个等待中的 tile | -0.01/step |

### 训练方式

```bash
# 完整训练（约 8~24 小时，取决于 CPU 性能）
python train_marl.py \
  --config examples/config.yaml \
  --out-dir checkpoints/run01 \
  --episodes 100 \
  --rollout-steps 128 \
  --ppo-epochs 4

# 快速验证（小规模，约 5~30 分钟）
python train_marl.py \
  --config examples/config.yaml \
  --out-dir checkpoints/quick \
  --episodes 10 \
  --rollout-steps 64

# 使用 MARL 策略对比
python run_mode_compare.py \
  --config examples/config.yaml \
  --policy marl \
  --marl-checkpoint checkpoints/run01/best.pt
```

### 文件位置

| 文件 | 说明 |
|------|------|
| `sim/marl/observation.py` | 89 维局部观测向量构建 |
| `sim/marl/reward.py` | Reward shaping（tile/task/fail/wait）|
| `sim/marl/actor.py` | SatActorCritic MLP 网络 |
| `train_marl.py` | IPPO 训练主脚本 |
| `sim/scheduler/marl_policy.py` | 推理接口（与 Greedy 相同接口）|
| `checkpoints/best.pt` | 训练最佳权重（需运行训练后生成）|

### 代码重构说明（env.py）

为支持 MARL 训练的高效调用，对原 `sim/env.py`（1069 行）进行了重构：

| 原位置 | 新位置 | 说明 |
|--------|--------|------|
| `_apply_actions` / `_advance_*` (distributed 逻辑) | `sim/pipeline/distributed.py` | `DistributedPipeline` 类 |
| `_start_ground_task_*` / `_advance_ground_*` (ground 逻辑) | `sim/pipeline/ground.py` | `GroundPipeline` 类 |
| `_refresh_ground_cache` / `_refresh_window_cache` / `_is_ground_visible` | `sim/cache/visibility.py` | `VisibilityCache` 类 |
| 核心骨架 | `sim/env.py` | 从 1069 行减少到 613 行 |
