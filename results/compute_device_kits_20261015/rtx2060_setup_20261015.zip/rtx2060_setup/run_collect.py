"""Collect device information without installing or changing anything."""
import sys

if sys.version_info < (3, 8):
    print("Python 3.8+ is required. Keep the current system/JetPack unchanged.")
    print("Return your Python version and device model for a compatible collector.")
    sys.exit(2)

from datetime import datetime, timezone
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
output = root / "results" / ("rtx2060_device_" + stamp + ".json")
print("Collecting rtx2060 inventory. No settings will be changed.", flush=True)
result = subprocess.run([
    sys.executable, str(root / "analysis" / "collect_compute_device.py"),
    "--output", str(output),
], cwd=str(root), check=False)
if result.returncode == 0:
    print("Return this JSON report: " + str(output))
    print("This was inventory collection, not a performance benchmark.")
sys.exit(result.returncode)
