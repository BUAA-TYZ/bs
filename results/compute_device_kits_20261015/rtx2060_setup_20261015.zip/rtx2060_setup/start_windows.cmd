@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 run_collect.py
) else (
    python run_collect.py
)
set "COLLECT_EXIT_CODE=%ERRORLEVEL%"
echo.
pause
exit /b %COLLECT_EXIT_CODE%
