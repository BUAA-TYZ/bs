# Jetson设备采集包

此包用于实验第一步：确认设备与软件版本。附带完整参数标定方案，暂不执行
GPU推理、训练、测速或功率模式修改，不包含模型权重和图像数据。

## 运行

先完整解压，再进入这个目录。只需要Python 3.8或以上，不用安装任何pip依赖，
无需sudo或管理员权限。采集过程中会显示一次开始提示，部分命令可能等待数秒。

在终端执行：

```bash
python3 run_collect.py
```

程序结束后，将 `results/jetson_device_时间戳.json` 带回来即可。
每次生成新文件，不覆盖旧报告；路径相对于本包，不要求原项目目录存在。
如果通过桌面入口运行窗口停留，看到结果后按任意键关闭。

## 缺失信息怎么处理

- `not_found`、`command_failed`、`timeout`等状态也属于有效记录，请保留完整JSON。
- 不要因为工具缺失或权限不足就重装JetPack、驱动或Python。
- Python低于3.8时，先记下版本和设备型号；不要升级系统Python来迁就本工具。
- Python包版本只代表运行本脚本的环境；有现成推理环境时可在该环境中再采一次。
- 另记录电源、散热器/风扇、室温和是否连接显示器，写入 `device_notes.txt`。

Jetson上没有nvidia-smi不代表采集失败。L4T/JetPack及板卡型号会另行查询；
功率模式或时钟查询若权限不足，报告会保留失败状态。

## 文件

- `run_collect.py`：设备专用入口，自动为报告命名。
- `analysis/collect_compute_device.py`：完整标准库采集脚本，可独立运行。
- `EXPERIMENT_PLAN.md`：当前Jetson与RTX 2060共同的实验方案，仅保留最新第0节。
- `device_notes.txt`：手工环境记录模板。
- `SHA256SUMS.json`：包内文件校验摘要。

方案中的E1–E5是后续测量协议；目前可直接执行的是E0设备采集。
具体CUDA/TensorRT测速入口将在设备型号与版本确认后适配，无需自行训练识别器。
